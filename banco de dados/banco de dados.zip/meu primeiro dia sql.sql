-- CRIAR O BANCO DE DADOS
CREATE DATABASE faculdade1adsc;

-- SELECIONE O BANCO DE DADOS faculdade1adsc
 USE faculdade1adsc;
 -- CHAR(), VARCHAR(), INT, DECIMAL(),FLOAT,DOUBLE,DATE,DATETIME
 -- CRIAR TABELA ALUNO
 CREATE table ALUNO (
 -- nome_do_campo tipos_do_campo pk
 Ra char(8) PRIMARY KEY, 
 NomeAluno VARCHAR(100),
 Bairro VARCHAR(100),
 Email VARCHAR(50) 
 );
-- NOSSO PRIMEIRO SELECT
-- * É IGUAL A TODOS OS CAMPOS
 SELECT * FROM ALUNO;
 
 -- INSERINDO O PRIMEIRO ALUNO
 INSERT INTO aluno VALUES
         ('01212182', 'DIEGO', 'ITAIM PAULISTA','DIEGO@BANDTEC.COM.BR'); 
 INSERT INTO aluno VALUES
          ('01212117', 'DANILO','VILA RENATO','DANILO@BANDTEC.COM.BR'),
          ('01212007','DOMINIQ','VILA ANASTACIA','DOMINIQ@BANDTEC.COM.BR'),
          ('01212085','LETICIA','SÃO BERNADO','LETICIA@BANDTEC.COM.BR');
          SELECT * FROM ALUNO;
          SELECT nomealuno, email FROM aluno;
          
          select nomealuno, email, bairro FROM aluno;
          
          SELECT bairro FROM aluno where BAIRRO = 'VILA ANASTACIA';
          
          SELECT nomealuno FROM ALUNO WHERE nomealuno LIKE '_A%';
          select nomealuno from aluno where nomealuno <> 'dominiq';
          select * from aluno order by nomealuno;
          select * from aluno order by  bairro desc;