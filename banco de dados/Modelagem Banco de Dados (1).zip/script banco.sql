create database sprint2;
use sprint2;


create table cadastro(
idcadastro int primary key auto_increment,
nome_empresa varchar(45),
email varchar (45),
cnpj varchar (45),
responsavel varchar (45)
);
insert into cadastro values
(null, 'Andorinha', 'andorinha@andorinha.com.br', 123456789, 'Paulo Sérgio'),
(null, 'Mococa', 'mococa@mococa.com.br', 123456798, 'Maria Fernanda');

select * from cadastro;

create table produtos(
idproduto int primary key auto_increment,
nome_produto varchar (45),
categoria varchar (45),
temp_max varchar (45),
temp_min varchar (45)
);

insert into produtos values
(null, 'Morango', 'Fruta', 8, 3),
(null, 'Leite', 'Bebida', 6, 4);

select * from produtos;

create table dados(
iddados int primary key auto_increment,
tempa_atual varchar (45),
fkcadastro int,
fkproduto int
);
alter table  dados add foreign key (fkcadastro) references  cadastro (idcadastro);
alter table dados add foreign key (fkproduto) references  produtos (idproduto) ;
insert into dados values
(null, 4.2, 1,1),
(null, 4.7, 2,2),
(null, 3.8, 1,1),
(null, 5, 1,1),
(null, 7.3, 2, 2),
(null, 9, 2, 2),
(null, 3.5, 2, 2);

select * from dados;
select cadastro.Nome from dados
join produtos
join cadastro
where fkcadastro = idcadastro
and fkproduto = idproduto;


 create table viagem (
idviagem int primary key auto_increment,
placa_caminhao char (8),
numero_sensor int,
fkcadastro int,
fkdados int
);
alter table viagem rename column  fkcadastro to fkcadastro_v;
alter table viagem add foreign key (fkcadastro_v) references cadastro (idcadastro);
alter table viagem add foreign key (fkdados) references dados (iddados);
select * from viagem;
desc viagem;
desc cadastro;
desc produtos;
desc dados;

insert into produto values 
()

